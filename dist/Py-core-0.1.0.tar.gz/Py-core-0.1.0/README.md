# Py_Core



## Getting started

To make it easy for you to get started with GitLab, here's a list of recommended next steps.

Already a pro? Just edit this README.md and make it your own. Want to make it easy? [Use the template at the bottom](#editing-this-readme)!

## Add your files

- [ ] [Create](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file) or [upload](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://docs.gitlab.com/ee/gitlab-basics/add-file.html#add-a-file-using-the-command-line) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin https://gitlab.obspm.fr/cceres/FlatSat/py_core.git
git branch -M main
git push -uf origin main
```

## Integrate with your tools

- [ ] [Set up project integrations](https://gitlab.obspm.fr/cceres/FlatSat/py_core/-/settings/integrations)

## Collaborate with your team

- [ ] [Invite team members and collaborators](https://docs.gitlab.com/ee/user/project/members/)
- [ ] [Create a new merge request](https://docs.gitlab.com/ee/user/project/merge_requests/creating_merge_requests.html)
- [ ] [Automatically close issues from merge requests](https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#closing-issues-automatically)
- [ ] [Enable merge request approvals](https://docs.gitlab.com/ee/user/project/merge_requests/approvals/)
- [ ] [Automatically merge when pipeline succeeds](https://docs.gitlab.com/ee/user/project/merge_requests/merge_when_pipeline_succeeds.html)

## Test and Deploy

Use the built-in continuous integration in GitLab.

- [ ] [Get started with GitLab CI/CD](https://docs.gitlab.com/ee/ci/quick_start/index.html)
- [ ] [Analyze your code for known vulnerabilities with Static Application Security Testing(SAST)](https://docs.gitlab.com/ee/user/application_security/sast/)
- [ ] [Deploy to Kubernetes, Amazon EC2, or Amazon ECS using Auto Deploy](https://docs.gitlab.com/ee/topics/autodevops/requirements.html)
- [ ] [Use pull-based deployments for improved Kubernetes management](https://docs.gitlab.com/ee/user/clusters/agent/)
- [ ] [Set up protected environments](https://docs.gitlab.com/ee/ci/environments/protected_environments.html)

***

# Editing this README

When you're ready to make this README your own, just edit this file and use the handy template below (or feel free to structure it however you want - this is just a starting point!). Thank you to [makeareadme.com](https://www.makeareadme.com/) for this template.

## Suggestions for a good README
Every project is different, so consider which of these sections apply to yours. The sections used in the template are suggestions for most open source projects. Also keep in mind that while a README can be too long and detailed, too long is better than too short. If you think your README is too long, consider utilizing another form of documentation rather than cutting out information.

## Name
Choose a self-explaining name for your project.
## Description
The aim of creating a new library that describes all I²C, SPI and CAN comunication protocol is to make  the communication between all sub-systems COM, OBC and EPS muh easier.

## Badges
On some READMEs, you may see small images that convey metadata, such as whether or not all the tests are passing for the project. You can use Shields to add some to your README. Many services also have instructions for adding a badge.

## Visuals
Depending on what you are making, it can be a good idea to include screenshots or even a video (you'll frequently see GIFs rather than actual videos). Tools like ttygif can help, but check out Asciinema for a more sophisticated method.

## Installation
To use this libray make sure you have installed every thing needed to run a python project on vscode under linux. If not here is a link to a tutorial that might be helpfull.  https://code.visualstudio.com/docs/python/python-tutorial

#####After having done all the settings, you will need to install this library. to do that here are some instructions :

- Download the library files from the source website or repository.
- Extract the downloaded files to a location on your computer where you want to install the library.
- Open a terminal or command prompt on your computer.
- Navigate to the directory where you extracted the library files using the "cd" command.
- Once you are in the correct directory, run the following command to install any dependencies that your library requires: "pip install -r requirements.txt" .
- After the dependencies are installed, run the following command to install your library: "python setup.py install".
- Wait for the installation process to complete.
- Verify that the library is installed correctly by importing it in a Python script and using its functions.

```
cd  path to the directory were the library were extracted
pip install -r requirements.txt
python setup.py install
```



#####If you fail to insatall the requirements.txt files here is a list of the depnedences 
#####and their versions : 

| Dependency | Version |
|------------|---------|
| arandr     | 0.1.9   |
| asn1crypto | 0.24.0  |
| automationhat | 0.2.0 |
| blinker    | 1.4     |
| blinkt     | 0.1.2   |
| buttonshim | 0.0.2   |
| Cap1xxx    | 0.1.3   |
| certifi    | 2018.8.24 |
| chardet    | 3.0.4   |
| Click      | 7.0     |
| colorama   | 0.3.7   |
| colorzero  | 1.1     |
| configparser | 3.5.0b2 |
| cookies    | 2.2.1   |
| cryptography | 2.6.1  |
| drumhat    | 0.1.0   |
| entrypoints | 0.3     |
| enum34     | 1.1.6   |
| envirophat | 1.0.0   |
| ExplorerHAT | 0.4.2  |
| Flask      | 1.0.2   |
| fourletterphat | 0.1.0 |
| funcsigs   | 1.0.2   |
| gpiozero   | 1.6.2   |
| gyp        | 0.1     |
| idna       | 2.6     |
| ipaddress  | 1.0.17  |
| itsdangerous | 0.24  |
| Jinja2     | 2.10    |
| keyring    | 17.1.1  |
| keyrings.alt | 3.1.1 |
| MarkupSafe | 1.1.0   |
| mcpi       | 0.1.1   |
| microdotphat | 0.2.1 |
| mock       | 2.0.0   |
| mote       | 0.0.4   |
| motephat   | 0.0.3   |
| numpy      | 1.16.2  |
| oauthlib   | 2.1.0   |
| olefile    | 0.46    |
| pandas     | 0.24.2  |
| pantilthat | 0.0.7   |
| pbr        | 4.2.0   |
| phatbeat   | 0.1.1   |
| pianohat   | 0.1.0   |
| picamera   | 1.13    |
| picraft    | 1.0     |
| piglow     | 1.2.5   |
| pigpio     | 1.78    |
| Pillow     | 5.4.1   |
| Py-core    | 0.1.0   |
| pycairo    | 1.16.2  |
| pycrypto   | 2.6.1   |
| pyflakes   | 2.0.0   |
| pygame     | 1.9.4.post1 |
| PyGObject  | 3.30.4  |
| pyinotify  | 0.9.6   |
| PyJWT      | 1.7.0   |
| pyOpenSSL  | 19.0.0  |


## Usage
Use examples liberally, and show the expected output if you can. It's helpful to have inline the smallest example of usage that you can demonstrate, while providing links to more sophisticated examples if they are too long to reasonably include in the README.

## Support
Tell people where they can go to for help. It can be any combination of an issue tracker, a chat room, an email address, etc.

## Roadmap
If you have ideas for releases in the future, it is a good idea to list them in the README.

## Contributing
State if you are open to contributions and what your requirements are for accepting them.

For people who want to make changes to your project, it's helpful to have some documentation on how to get started. Perhaps there is a script that they should run or some environment variables that they need to set. Make these steps explicit. These instructions could also be useful to your future self.

You can also document commands to lint the code or run tests. These steps help to ensure high code quality and reduce the likelihood that the changes inadvertently break something. Having instructions for running tests is especially helpful if it requires external setup, such as starting a Selenium server for testing in a browser.

## Authors and acknowledgment
Show your appreciation to those who have contributed to the project.

## License
For open source projects, say how it is licensed.

## Project status
If you have run out of energy or time for your project, put a note at the top of the README saying that development has slowed down or stopped completely. Someone may choose to fork your project or volunteer to step in as a maintainer or owner, allowing your project to keep going. You can also make an explicit request for maintainers.
## To get dependencies and their updated version
 Here is the link to pypi : https://pypi.org/